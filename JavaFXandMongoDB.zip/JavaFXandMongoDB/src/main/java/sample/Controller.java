package sample;

import controler.mongodb;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import org.bson.Document;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class Controller extends Application implements Initializable {
    private static Application instance;


    @FXML
    private ListView listView;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        populateListTest();

    }


    /* Testing Stuff */
    public void insertCustomer(ActionEvent event) {
        System.out.println("Dummy Daten eingetragen f�r Kunden");
        mongodb myMongoDB = new mongodb(mongodb.collections.customer);
        Document data = new Document("keyCustomer", "value");
        myMongoDB.insertData(data);
        myMongoDB.closeDbConnection();

    }


    public void insertArticle(ActionEvent event) {
        System.out.println("Dummy Daten eingetragen f�r Artikel");
        mongodb myMongoDB = new mongodb(mongodb.collections.article);
        Document data = new Document("keyArticle", "value");
        myMongoDB.insertData(data);
        myMongoDB.closeDbConnection();
    }



    private void populateListTest(){
        ArrayList tmpValues = new ArrayList();

        for (int i = 0; i < 1000; i++) {
            tmpValues.add(i);
        }

        listView.setItems(FXCollections.observableList(tmpValues));

    }

    @Override
    public void start(Stage primaryStage) throws Exception {

    }


    /* Testing Stuff */


}
