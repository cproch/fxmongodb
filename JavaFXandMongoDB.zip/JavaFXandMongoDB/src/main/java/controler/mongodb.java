package controler;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;


public class mongodb {

    private MongoClient mongoClient;
    private MongoCollection<Document> mongoCollection;
    private final String database="auftragsbearbeitung";
    public enum collections{
        customer,article,administrator,order
    }

    public mongodb(collections collection) {


/*        List<Document> seedData = new ArrayList<Document>();

        seedData.add(new Document("decade", "1970s")
                .append("artist", "Debby Boone")
                .append("song", "You Light Up My Life")
                .append("weeksAtOne", 10)
        );

        seedData.add(new Document("decade", "1980s")
                .append("artist", "Olivia Newton-John")
                .append("song", "Physical")
                .append("weeksAtOne", 10)
        );

        seedData.add(new Document("decade", "1990s")
                .append("artist", "Mariah Carey")
                .append("song", "One Sweet Day")
                .append("weeksAtOne", 16)
        );
*/
        MongoClientURI uri = new MongoClientURI("mongodb://localhost:27017");
        MongoClient mongoClient = new MongoClient(uri);
        MongoDatabase mongoDatabase = mongoClient.getDatabase(database);
        this.mongoClient=mongoClient;
        this.mongoCollection= mongoDatabase.getCollection(collection.toString());


    }

    public void insertData(Document data ){
        mongoCollection.insertOne(data);
    }


    public void closeDbConnection(){
        this.mongoClient.close();
    }


}
